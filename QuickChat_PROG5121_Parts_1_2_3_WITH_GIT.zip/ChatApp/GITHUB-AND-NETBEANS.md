# NetBeans and GitHub hand-off — PROG5121 QuickChat

## Open the project in NetBeans
1. Extract the ZIP file.
2. Open NetBeans and choose **File → Open Project**.
3. Select the `ChatApp` folder (the folder containing `pom.xml`).
4. Set the project JDK to Java 21.
5. Right-click the project and select **Clean and Build**.
6. Run `com.mycompany.chatapp.ChatApp`.

This is a Java console application. The brief explicitly disallows GUI/JOptionPane interfaces.

## Test the project
From a terminal in the project folder, run:

```bash
mvn --batch-mode clean test
```

The Java production sources were compiled successfully with `javac --release 21` during preparation. Maven was not available in the preparation environment, so the JUnit suite has not been executed here. Run it locally and check the test results before submission.

## Git identity
The local Git configuration is set to:

```text
Name: Godwin Sabela
Email: godwinxolile9@gmail.com
```

This config sets the author identity for future commits; it does not log in to GitHub. Earlier commits in the supplied repository retain their original author metadata.

## Existing repository remote
The supplied repository history already has this remote:

```text
https://github.com/godwinxolile9-bit/ChatApp_Prog
```

The ZIP preserves the original `.git` history and this remote. No push is claimed by this package. A GitHub account connection/authentication is required before publishing changes.

To inspect the repository state:

```bash
git status
git log --oneline --decorate
git remote -v
```

To publish the current branch after signing in to GitHub:

```bash
git push -u origin master
```

If your lecturer requires the branch to be named `main`, rename it deliberately before pushing:

```bash
git branch -M main
git push -u origin main
```

Do not create a second remote or overwrite an existing GitHub repository without checking its contents first. Never put a GitHub password or personal access token in source code or chat.

## Rubric and commit requirement
The supplied PoE states that each part needs at least six commits and that Parts 1, 2 and 3 must be pushed to GitHub. The original ZIP contains a real 16-commit development history spanning registration/login, messaging, JSON persistence, arrays/search/reporting, tests, and documentation. The latest hand-off documentation is an additional real commit.

Do not manufacture empty or misleading commits to reach a number. Review and test the implementation, make meaningful changes as you work through each part, and commit each genuine checkpoint with a clear message. The historical commit count alone should not be represented as proof that every part independently meets the six-commit rule; verify the commit breakdown with your lecturer's required submission method.

## Submission checks from the PoE
- Run all JUnit tests locally and retain the passing test output.
- Push the correct repository and verify the GitHub Actions workflow is green.
- Record the required code demonstration in your own voice, explaining the application and its logic.
- Submit the repository URL and presentation link through the student portal.

This package is a working Java project hand-off, not proof of lecturer marks, a successful remote push, or a completed presentation.
